adds chicken blocks and stuff
