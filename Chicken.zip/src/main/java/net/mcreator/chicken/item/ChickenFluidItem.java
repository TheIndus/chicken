
package net.mcreator.chicken.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.chicken.init.ChickenModFluids;

public class ChickenFluidItem extends BucketItem {
	public ChickenFluidItem() {
		super(ChickenModFluids.CHICKEN_FLUID, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.COMMON));
	}
}
