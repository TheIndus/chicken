
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chicken.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.chicken.fluid.types.ChickenFluidFluidType;
import net.mcreator.chicken.ChickenMod;

public class ChickenModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, ChickenMod.MODID);
	public static final RegistryObject<FluidType> CHICKEN_FLUID_TYPE = REGISTRY.register("chicken_fluid", () -> new ChickenFluidFluidType());
}
