
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chicken.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;

import net.mcreator.chicken.item.ChickenToolItem;
import net.mcreator.chicken.item.ChickenItemItem;
import net.mcreator.chicken.item.ChickenFluidItem;
import net.mcreator.chicken.item.ChickenDimensionItem;
import net.mcreator.chicken.item.ChickenArmorItem;
import net.mcreator.chicken.ChickenMod;

public class ChickenModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ChickenMod.MODID);
	public static final RegistryObject<Item> BLOCK_OF_CHICKEN = block(ChickenModBlocks.BLOCK_OF_CHICKEN);
	public static final RegistryObject<Item> CHICKEN_STAIRS = block(ChickenModBlocks.CHICKEN_STAIRS);
	public static final RegistryObject<Item> CHICKEN_SLAB = block(ChickenModBlocks.CHICKEN_SLAB);
	public static final RegistryObject<Item> CHICKEN_FENCE = block(ChickenModBlocks.CHICKEN_FENCE);
	public static final RegistryObject<Item> CHICKEN_WALL = block(ChickenModBlocks.CHICKEN_WALL);
	public static final RegistryObject<Item> CHICKEN_LEAVES = block(ChickenModBlocks.CHICKEN_LEAVES);
	public static final RegistryObject<Item> CHICKEN_TRAPDOOR = block(ChickenModBlocks.CHICKEN_TRAPDOOR);
	public static final RegistryObject<Item> CHICKEN_PANE = block(ChickenModBlocks.CHICKEN_PANE);
	public static final RegistryObject<Item> CHICKEN_DOOR = doubleBlock(ChickenModBlocks.CHICKEN_DOOR);
	public static final RegistryObject<Item> CHICKEN_FENCE_GATE = block(ChickenModBlocks.CHICKEN_FENCE_GATE);
	public static final RegistryObject<Item> CHICKEN_ROD = block(ChickenModBlocks.CHICKEN_ROD);
	public static final RegistryObject<Item> CHICKEN_PRESSURE_PLATE = block(ChickenModBlocks.CHICKEN_PRESSURE_PLATE);
	public static final RegistryObject<Item> CHICKEN_BUTTON = block(ChickenModBlocks.CHICKEN_BUTTON);
	public static final RegistryObject<Item> HEAVY_BLOCKOF_CHICKEN = block(ChickenModBlocks.HEAVY_BLOCKOF_CHICKEN);
	public static final RegistryObject<Item> CHICKEN_FLUID_BUCKET = REGISTRY.register("chicken_fluid_bucket", () -> new ChickenFluidItem());
	public static final RegistryObject<Item> CHICKEN_ARMOR_HELMET = REGISTRY.register("chicken_armor_helmet", () -> new ChickenArmorItem.Helmet());
	public static final RegistryObject<Item> CHICKEN_ARMOR_CHESTPLATE = REGISTRY.register("chicken_armor_chestplate", () -> new ChickenArmorItem.Chestplate());
	public static final RegistryObject<Item> CHICKEN_ARMOR_LEGGINGS = REGISTRY.register("chicken_armor_leggings", () -> new ChickenArmorItem.Leggings());
	public static final RegistryObject<Item> CHICKEN_ARMOR_BOOTS = REGISTRY.register("chicken_armor_boots", () -> new ChickenArmorItem.Boots());
	public static final RegistryObject<Item> CHICKEN_ITEM = REGISTRY.register("chicken_item", () -> new ChickenItemItem());
	public static final RegistryObject<Item> CHICKEN_TOOL = REGISTRY.register("chicken_tool", () -> new ChickenToolItem());
	public static final RegistryObject<Item> CHICKEN_GRASS = block(ChickenModBlocks.CHICKEN_GRASS);
	public static final RegistryObject<Item> CHICKEN_WOOD = block(ChickenModBlocks.CHICKEN_WOOD);
	public static final RegistryObject<Item> CHICKEN_DIMENSION = REGISTRY.register("chicken_dimension", () -> new ChickenDimensionItem());
	public static final RegistryObject<Item> CHICKEN_PLANKS = block(ChickenModBlocks.CHICKEN_PLANKS);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	private static RegistryObject<Item> doubleBlock(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), new Item.Properties()));
	}
}
