
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chicken.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.chicken.ChickenMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ChickenModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ChickenMod.MODID);
	public static final RegistryObject<CreativeModeTab> CHICKEN = REGISTRY.register("chicken",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.chicken.chicken")).icon(() -> new ItemStack(ChickenModBlocks.BLOCK_OF_CHICKEN.get())).displayItems((parameters, tabData) -> {
				tabData.accept(ChickenModBlocks.BLOCK_OF_CHICKEN.get().asItem());
				tabData.accept(ChickenModBlocks.CHICKEN_STAIRS.get().asItem());
				tabData.accept(ChickenModBlocks.CHICKEN_SLAB.get().asItem());
				tabData.accept(ChickenModBlocks.CHICKEN_FENCE.get().asItem());
				tabData.accept(ChickenModBlocks.CHICKEN_WALL.get().asItem());
				tabData.accept(ChickenModBlocks.CHICKEN_LEAVES.get().asItem());
				tabData.accept(ChickenModBlocks.CHICKEN_TRAPDOOR.get().asItem());
				tabData.accept(ChickenModBlocks.CHICKEN_PANE.get().asItem());
				tabData.accept(ChickenModBlocks.CHICKEN_DOOR.get().asItem());
				tabData.accept(ChickenModBlocks.CHICKEN_FENCE_GATE.get().asItem());
				tabData.accept(ChickenModBlocks.CHICKEN_ROD.get().asItem());
				tabData.accept(ChickenModBlocks.CHICKEN_PRESSURE_PLATE.get().asItem());
				tabData.accept(ChickenModBlocks.CHICKEN_BUTTON.get().asItem());
				tabData.accept(ChickenModBlocks.HEAVY_BLOCKOF_CHICKEN.get().asItem());
				tabData.accept(ChickenModItems.CHICKEN_FLUID_BUCKET.get());
				tabData.accept(ChickenModItems.CHICKEN_ARMOR_HELMET.get());
				tabData.accept(ChickenModItems.CHICKEN_ARMOR_CHESTPLATE.get());
				tabData.accept(ChickenModItems.CHICKEN_ARMOR_LEGGINGS.get());
				tabData.accept(ChickenModItems.CHICKEN_ARMOR_BOOTS.get());
				tabData.accept(ChickenModItems.CHICKEN_ITEM.get());
				tabData.accept(ChickenModItems.CHICKEN_TOOL.get());
				tabData.accept(ChickenModBlocks.CHICKEN_GRASS.get().asItem());
				tabData.accept(ChickenModBlocks.CHICKEN_WOOD.get().asItem());
				tabData.accept(ChickenModItems.CHICKEN_DIMENSION.get());
				tabData.accept(ChickenModBlocks.CHICKEN_PLANKS.get().asItem());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {

			tabData.accept(ChickenModItems.CHICKEN_TOOL.get());

		}
	}
}
