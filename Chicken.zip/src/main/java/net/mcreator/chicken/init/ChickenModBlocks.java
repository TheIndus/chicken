
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chicken.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.chicken.block.HeavyBlockofChickenBlock;
import net.mcreator.chicken.block.ChickenWoodBlock;
import net.mcreator.chicken.block.ChickenWallBlock;
import net.mcreator.chicken.block.ChickenTrapdoorBlock;
import net.mcreator.chicken.block.ChickenStairsBlock;
import net.mcreator.chicken.block.ChickenSlabBlock;
import net.mcreator.chicken.block.ChickenRodBlock;
import net.mcreator.chicken.block.ChickenPressurePlateBlock;
import net.mcreator.chicken.block.ChickenPlanksBlock;
import net.mcreator.chicken.block.ChickenPaneBlock;
import net.mcreator.chicken.block.ChickenLeavesBlock;
import net.mcreator.chicken.block.ChickenGrassBlock;
import net.mcreator.chicken.block.ChickenFluidBlock;
import net.mcreator.chicken.block.ChickenFenceGateBlock;
import net.mcreator.chicken.block.ChickenFenceBlock;
import net.mcreator.chicken.block.ChickenDoorBlock;
import net.mcreator.chicken.block.ChickenDimensionPortalBlock;
import net.mcreator.chicken.block.ChickenButtonBlock;
import net.mcreator.chicken.block.BlockofchickenBlock;
import net.mcreator.chicken.ChickenMod;

public class ChickenModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ChickenMod.MODID);
	public static final RegistryObject<Block> BLOCK_OF_CHICKEN = REGISTRY.register("block_of_chicken", () -> new BlockofchickenBlock());
	public static final RegistryObject<Block> CHICKEN_STAIRS = REGISTRY.register("chicken_stairs", () -> new ChickenStairsBlock());
	public static final RegistryObject<Block> CHICKEN_SLAB = REGISTRY.register("chicken_slab", () -> new ChickenSlabBlock());
	public static final RegistryObject<Block> CHICKEN_FENCE = REGISTRY.register("chicken_fence", () -> new ChickenFenceBlock());
	public static final RegistryObject<Block> CHICKEN_WALL = REGISTRY.register("chicken_wall", () -> new ChickenWallBlock());
	public static final RegistryObject<Block> CHICKEN_LEAVES = REGISTRY.register("chicken_leaves", () -> new ChickenLeavesBlock());
	public static final RegistryObject<Block> CHICKEN_TRAPDOOR = REGISTRY.register("chicken_trapdoor", () -> new ChickenTrapdoorBlock());
	public static final RegistryObject<Block> CHICKEN_PANE = REGISTRY.register("chicken_pane", () -> new ChickenPaneBlock());
	public static final RegistryObject<Block> CHICKEN_DOOR = REGISTRY.register("chicken_door", () -> new ChickenDoorBlock());
	public static final RegistryObject<Block> CHICKEN_FENCE_GATE = REGISTRY.register("chicken_fence_gate", () -> new ChickenFenceGateBlock());
	public static final RegistryObject<Block> CHICKEN_ROD = REGISTRY.register("chicken_rod", () -> new ChickenRodBlock());
	public static final RegistryObject<Block> CHICKEN_PRESSURE_PLATE = REGISTRY.register("chicken_pressure_plate", () -> new ChickenPressurePlateBlock());
	public static final RegistryObject<Block> CHICKEN_BUTTON = REGISTRY.register("chicken_button", () -> new ChickenButtonBlock());
	public static final RegistryObject<Block> HEAVY_BLOCKOF_CHICKEN = REGISTRY.register("heavy_blockof_chicken", () -> new HeavyBlockofChickenBlock());
	public static final RegistryObject<Block> CHICKEN_FLUID = REGISTRY.register("chicken_fluid", () -> new ChickenFluidBlock());
	public static final RegistryObject<Block> CHICKEN_GRASS = REGISTRY.register("chicken_grass", () -> new ChickenGrassBlock());
	public static final RegistryObject<Block> CHICKEN_WOOD = REGISTRY.register("chicken_wood", () -> new ChickenWoodBlock());
	public static final RegistryObject<Block> CHICKEN_DIMENSION_PORTAL = REGISTRY.register("chicken_dimension_portal", () -> new ChickenDimensionPortalBlock());
	public static final RegistryObject<Block> CHICKEN_PLANKS = REGISTRY.register("chicken_planks", () -> new ChickenPlanksBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
