
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chicken.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.chicken.fluid.ChickenFluidFluid;
import net.mcreator.chicken.ChickenMod;

public class ChickenModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, ChickenMod.MODID);
	public static final RegistryObject<FlowingFluid> CHICKEN_FLUID = REGISTRY.register("chicken_fluid", () -> new ChickenFluidFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_CHICKEN_FLUID = REGISTRY.register("flowing_chicken_fluid", () -> new ChickenFluidFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(CHICKEN_FLUID.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_CHICKEN_FLUID.get(), RenderType.translucent());
		}
	}
}
