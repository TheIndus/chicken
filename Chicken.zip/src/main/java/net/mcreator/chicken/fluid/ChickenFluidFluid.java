
package net.mcreator.chicken.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.chicken.init.ChickenModItems;
import net.mcreator.chicken.init.ChickenModFluids;
import net.mcreator.chicken.init.ChickenModFluidTypes;
import net.mcreator.chicken.init.ChickenModBlocks;

public abstract class ChickenFluidFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> ChickenModFluidTypes.CHICKEN_FLUID_TYPE.get(), () -> ChickenModFluids.CHICKEN_FLUID.get(), () -> ChickenModFluids.FLOWING_CHICKEN_FLUID.get())
			.explosionResistance(100f).tickRate(10).bucket(() -> ChickenModItems.CHICKEN_FLUID_BUCKET.get()).block(() -> (LiquidBlock) ChickenModBlocks.CHICKEN_FLUID.get());

	private ChickenFluidFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.EGG_CRACK;
	}

	public static class Source extends ChickenFluidFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends ChickenFluidFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
