
package net.mcreator.chicken.block;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.common.util.ForgeSoundType;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.resources.ResourceLocation;

public class ChickenWallBlock extends WallBlock {
	public ChickenWallBlock() {
		super(BlockBehaviour.Properties.of()
				.sound(new ForgeSoundType(1.0f, 1.0f, () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.chicken.death")), () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.chicken.egg")),
						() -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.chicken.ambient")), () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.chicken.hurt")),
						() -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.chicken.hurt"))))
				.strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false).forceSolidOn());
	}
}
